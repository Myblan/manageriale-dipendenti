package it.corso.dao;

import org.springframework.data.repository.CrudRepository;

import it.corso.model.Ruolo;

public interface RuoloDao extends CrudRepository<Ruolo, Integer>{

}
